from __future__ import annotations

import copy
import json
import sys
import unittest
from pathlib import Path


PLUGIN = Path(__file__).resolve().parents[1]
FIXTURES = PLUGIN / "tests" / "fixtures" / "packaging"
sys.path.insert(0, str(PLUGIN / "scripts"))

import aicad_packaging_qa as qa  # noqa: E402


class PackagingDielineRuleRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.geometry_path = FIXTURES / "geometry.json"
        cls.rules_path = PLUGIN / "rules" / "packaging_dieline_rules.json"
        cls.geometry = json.loads(cls.geometry_path.read_text(encoding="utf-8"))
        cls.rules = json.loads(cls.rules_path.read_text(encoding="utf-8"))

    def result(self, geometry, rule_id):
        rows = qa.geometry_checks(geometry, self.rules)
        return next(row for row in rows if row["rule_id"] == rule_id)

    def test_current_exact_fillet_passes_tangency(self):
        row = self.result(copy.deepcopy(self.geometry), "PKG-G002")
        self.assertTrue(row["pass"])
        self.assertLessEqual(row["evidence"]["max_angle_error_deg"], qa.ANGLE_TOL_DEG)

    def test_endpoint_only_corner_is_rejected(self):
        broken = copy.deepcopy(self.geometry)
        arc = next(item for item in broken["entities"] if item["id"] == "ARC_T_P1_L")
        arc["center"][0] += 0.5
        row = self.result(broken, "PKG-G002")
        self.assertFalse(row["pass"], "a corner that merely looks connected must fail the tangency gate")

    def test_duplicate_entity_is_rejected(self):
        broken = copy.deepcopy(self.geometry)
        duplicate = copy.deepcopy(next(item for item in broken["entities"] if item["id"] == "CUT_JOINT_TOP"))
        duplicate["id"] = "CUT_JOINT_TOP_DUPLICATE"
        broken["entities"].append(duplicate)
        row = self.result(broken, "PKG-G003")
        self.assertFalse(row["pass"])
        self.assertGreater(row["evidence"]["duplicate_count"], 0)

    def test_asymmetric_v_slot_is_rejected(self):
        broken = copy.deepcopy(self.geometry)
        edge = next(item for item in broken["entities"] if item["id"] == "SLOT_T_P2_L")
        edge["end"][0] += 0.25
        row = self.result(broken, "PKG-G004")
        self.assertFalse(row["pass"])

    def test_frame_and_semantic_delivery_rules_are_persistent(self):
        rule_ids = {row["id"] for row in self.rules["rules"]}
        self.assertTrue({"PKG-G010", "PKG-G011", "PKG-G012", "PKG-G013"}.issubset(rule_ids))
        for rule_id in ("PKG-G010", "PKG-G011", "PKG-G012", "PKG-G013"):
            row = next(item for item in self.rules["rules"] if item["id"] == rule_id)
            self.assertTrue(row["failure_cause"])
            self.assertTrue(row["prevention"])

    def test_reference_frame_config_preserves_production_scale(self):
        config_path = FIXTURES / "frame-config.json"
        config = json.loads(config_path.read_text(encoding="utf-8"))
        self.assertEqual(config["reference_measurements_mm"]["outer"], [420, 297])
        self.assertEqual(config["reference_measurements_mm"]["inner_margins"],
                         {"left": 25, "top": 5, "right": 5, "bottom": 5})
        self.assertEqual(config["implementation"]["model_space"], "1:1 unchanged")
        self.assertEqual(config["implementation"]["locked_viewport_scale"], "1:5")

    def test_native_sheet_rules_and_config_are_persistent(self):
        rule_ids = {row["id"] for row in self.rules["rules"]}
        required = {"PKG-G014", "PKG-G015", "PKG-G016", "PKG-G017"}
        self.assertTrue(required.issubset(rule_ids))
        config_path = FIXTURES / "native-sheet-config.json"
        config = json.loads(config_path.read_text(encoding="utf-8"))
        self.assertEqual(config["dimensioning"]["counts"], {"linear": 10, "radius": 1, "total": 11})
        self.assertEqual(config["dimensioning"]["native_entity_types"]["radius"], "AcDbRadialDimension")
        self.assertFalse(config["dimensioning"]["text_override_allowed"])
        self.assertEqual(config["title_block"]["school"], "STU")
        self.assertEqual(config["title_block"]["name"], "明明")
        self.assertEqual(config["title_block"]["removed_reference_examples"], ["班级", "专业", "成绩", "学号"])
        self.assertIn("inside frame", config["technical_requirements"]["location"])


if __name__ == "__main__":
    unittest.main()
